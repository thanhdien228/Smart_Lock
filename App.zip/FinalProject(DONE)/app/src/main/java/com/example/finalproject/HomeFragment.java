package com.example.finalproject;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.History.History;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.w3c.dom.Text;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private Button btn_Open;
    private TextView txt_Status;
    private ImageView img_Status;
    private DatabaseReference doorStatusRef; // Tham chiếu đến dữ liệu "door_status" trong Firebase
    private boolean check = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        btn_Open = view.findViewById(R.id.btn_Open);
        txt_Status = view.findViewById(R.id.txt_Status);
        img_Status = view.findViewById(R.id.img_Status);

        btn_Open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Khi nút được nhấn, cập nhật giá trị door_status thành 1
                check = !check;
                if(check == false){
                    btn_Open.setText("CLOSE");
                    doorStatusRef.setValue(1);
                }
                else {
                    btn_Open.setText("OPEN");
                    doorStatusRef.setValue(0);
                }
            }
        });

        // Kết nối đến Firebase và lắng nghe sự thay đổi của dữ liệu "door_status"
        doorStatusRef = FirebaseDatabase.getInstance().getReference().child("door_status");

        doorStatusRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Kiểm tra và cập nhật giao diện tương ứng với giá trị door_status
                Integer doorStatus = dataSnapshot.getValue(Integer.class);
                if (doorStatus != null) {
                    updateUI(doorStatus); // Phương thức để cập nhật giao diện
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Xử lý khi có lỗi xảy ra trong việc đọc dữ liệu từ Firebase
            }
        });

        return view;
    }

    // Phương thức để cập nhật giao diện dựa trên giá trị door_status
    private void updateUI(int doorStatus) {
        // Tùy thuộc vào giá trị doorStatus, thay đổi TextView và ImageView
        switch (doorStatus) {
            case 0:
                txt_Status.setText("Door is closed");
                btn_Open.setText("OPEN");
                img_Status.setImageResource(R.drawable.safety);
                break;
            case 1:
                txt_Status.setText("Door is open");
                btn_Open.setText("CLOSE");
                img_Status.setImageResource(R.drawable.unlock);
                break;
            case 2:
                txt_Status.setText("Door is in unknown state");
                img_Status.setImageResource(R.drawable.warning);
                break;
            default:
                // Xử lý trường hợp không xác định khác nếu cần
                break;
        }
    }
}

