package com.example.finalproject.History;

public class History {
    private String day;
    private String hour;
    private String type;

    public History(String day, String hour, String type) {
        this.day = day;
        this.hour = hour;
        this.type = type;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
