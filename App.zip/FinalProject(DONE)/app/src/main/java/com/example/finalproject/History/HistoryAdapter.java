package com.example.finalproject.History;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.HistoryFragment;
import com.example.finalproject.R;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {
    private List<History> historyList;

    public HistoryAdapter(List<History> historyList) {
        this.historyList = historyList;
    }

    @NonNull
    @Override
    public HistoryAdapter.HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_room,parent,false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.HistoryViewHolder holder, int position) {
        History history = historyList.get(position);
        if (history == null){
            return;
        }
        holder.txt_Day.setText(history.getDay());
        holder.txt_Hour.setText((history.getHour()));
        holder.txtType.setText(history.getType());
    }

    @Override
    public int getItemCount() {
        if (historyList != null){
            return historyList.size();
        }
        return 0;
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder{
        private TextView txt_Day, txt_Hour, txtType;
        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_Day = itemView.findViewById(R.id.txt_Day);
            txt_Hour = itemView.findViewById(R.id.txt_Hour);
            txtType = itemView.findViewById((R.id.txt_Type));
        }
    }
}
