package com.example.finalproject;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.finalproject.History.History;
import com.example.finalproject.History.HistoryAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HistoryFragment extends Fragment {
    private RecyclerView rcv_History;
    private HistoryAdapter historyAdapter;
    private List<History> historyList;
    private DatabaseReference databaseReference;
    MainActivity mainActivity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        rcv_History = view.findViewById(R.id.rcv_History);
        rcv_History.setHasFixedSize(true);
        rcv_History.setLayoutManager(new LinearLayoutManager(mainActivity));
        historyList = new ArrayList<>();
        historyAdapter = new HistoryAdapter(historyList);
        rcv_History.setAdapter(historyAdapter);

        // Kết nối đến Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference().child("door_history");

        // Lắng nghe sự thay đổi trong Firebase Database
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                historyList.clear(); // Xóa dữ liệu cũ trước khi cập nhật mới
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // Lấy thông tin từ dataSnapshot và tạo đối tượng History
                    String day = snapshot.child("ngay").getValue(String.class);
                    String hour = snapshot.child("gio").getValue(String.class);
                    String type = snapshot.child("user").getValue(String.class);

                    // Tạo một đối tượng History mới
                    History history = new History(day, hour, type);
                    historyList.add(history);
                }
                // Sau khi lấy dữ liệu từ Firebase, cập nhật RecyclerView
                historyAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Xử lý khi có lỗi xảy ra trong Firebase
            }
        });

        return view;
    }
}